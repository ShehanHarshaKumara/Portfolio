import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

export function AnimatedRobot() {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      className="relative w-64 h-64 mx-auto"
      animate={{
        y: [0, -10, 0],
        rotateY: [0, 5, 0, -5, 0],
      }}
      transition={{
        duration: 4,
        repeat: Infinity,
        ease: "easeInOut"
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      {/* Robot Body */}
      <motion.div
        className="absolute inset-x-8 top-16 bottom-8 bg-gradient-to-b from-slate-300 to-slate-400 rounded-3xl shadow-2xl"
        animate={isHovered ? { scale: 1.05 } : { scale: 1 }}
        transition={{ duration: 0.3 }}
        style={{
          background: 'linear-gradient(145deg, #e2e8f0, #cbd5e1)',
          boxShadow: '20px 20px 40px #94a3b8, -20px -20px 40px #ffffff'
        }}
      >
        {/* Chest Panel */}
        <div className="absolute inset-x-4 top-8 h-16 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-2xl">
          <motion.div
            className="w-4 h-4 bg-green-400 rounded-full absolute top-2 left-2"
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <motion.div
            className="w-3 h-3 bg-red-400 rounded-full absolute top-2 right-2"
            animate={{ opacity: [0.3, 1, 0.3] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
        </div>
      </motion.div>

      {/* Robot Head */}
      <motion.div
        className="absolute inset-x-12 top-0 h-20 bg-gradient-to-b from-slate-200 to-slate-300 rounded-2xl shadow-xl"
        animate={isHovered ? { 
          rotateX: [0, -10, 0],
          rotateZ: [0, 2, -2, 0] 
        } : {}}
        transition={{ duration: 0.6 }}
        style={{
          background: 'linear-gradient(145deg, #f1f5f9, #e2e8f0)',
          boxShadow: '15px 15px 30px #94a3b8, -15px -15px 30px #ffffff'
        }}
      >
        {/* Eyes */}
        <motion.div
          className="flex justify-between px-4 pt-4"
          animate={isHovered ? { scale: 1.2 } : { scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <motion.div
            className="w-6 h-6 bg-cyan-400 rounded-full shadow-inner"
            animate={{ 
              boxShadow: isHovered 
                ? ['inset 2px 2px 4px #0891b2', 'inset -2px -2px 4px #22d3ee']
                : 'inset 2px 2px 4px #0891b2'
            }}
            transition={{ duration: 0.5, repeat: isHovered ? Infinity : 0 }}
          />
          <motion.div
            className="w-6 h-6 bg-cyan-400 rounded-full shadow-inner"
            animate={{ 
              boxShadow: isHovered 
                ? ['inset -2px -2px 4px #22d3ee', 'inset 2px 2px 4px #0891b2']
                : 'inset 2px 2px 4px #0891b2'
            }}
            transition={{ duration: 0.5, repeat: isHovered ? Infinity : 0, delay: 0.25 }}
          />
        </motion.div>

        {/* Antenna */}
        <motion.div
          className="absolute -top-4 left-1/2 transform -translate-x-1/2"
          animate={{
            rotate: [0, 10, -10, 0],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="w-1 h-6 bg-slate-400 rounded-full"></div>
          <motion.div
            className="w-3 h-3 bg-red-500 rounded-full absolute -top-1 left-1/2 transform -translate-x-1/2"
            animate={{ 
              scale: [1, 1.3, 1],
              opacity: [1, 0.7, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
          />
        </motion.div>
      </motion.div>

      {/* Arms */}
      <motion.div
        className="absolute -left-8 top-20 w-6 h-24 bg-gradient-to-b from-slate-300 to-slate-400 rounded-full shadow-lg"
        animate={{
          rotate: [0, 10, -5, 0],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          transformOrigin: 'top center'
        }}
      />
      <motion.div
        className="absolute -right-8 top-20 w-6 h-24 bg-gradient-to-b from-slate-300 to-slate-400 rounded-full shadow-lg"
        animate={{
          rotate: [0, -10, 5, 0],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          transformOrigin: 'top center'
        }}
      />

      {/* Legs */}
      <motion.div
        className="absolute left-6 -bottom-8 w-5 h-16 bg-gradient-to-b from-slate-400 to-slate-500 rounded-full shadow-lg"
        animate={{
          scaleY: [1, 0.95, 1],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div
        className="absolute right-6 -bottom-8 w-5 h-16 bg-gradient-to-b from-slate-400 to-slate-500 rounded-full shadow-lg"
        animate={{
          scaleY: [1, 0.95, 1],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1
        }}
      />

      {/* Floating particles around robot */}
      {[...Array(6)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-cyan-400 rounded-full opacity-60"
          animate={{
            x: [0, Math.cos(i * 60 * Math.PI / 180) * 100],
            y: [0, Math.sin(i * 60 * Math.PI / 180) * 100],
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            delay: i * 0.5,
            ease: "easeInOut"
          }}
          style={{
            left: '50%',
            top: '50%',
          }}
        />
      ))}
    </motion.div>
  );
}